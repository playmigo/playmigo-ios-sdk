//
//  ServiceCommandDelegate.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.
//  Copyright © 2016 Digisoft.tv.
//
 

#import <Foundation/Foundation.h>

@class ServiceCommand;
@class ServiceSubscription;
@class ServiceAsyncCommand;

@protocol ServiceCommandDelegate <NSObject>

typedef enum {
    ServiceSubscriptionTypeUnsubscribe = NO,
    ServiceSubscriptionTypeSubscribe = YES
} ServiceSubscriptionType;

@optional

- (int) sendCommand:(ServiceCommand *)comm withPayload:(id)payload toURL:(NSURL*)URL;
- (int) sendSubscription:(ServiceSubscription *)subscription type:(ServiceSubscriptionType)type payload:(id)payload toURL:(NSURL *)URL withId:(int)callId;
- (int) sendAsync:(ServiceAsyncCommand *)async withPayload:(id)payload toURL:(NSURL*)URL;

@end

//
//  Playmigo.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.6.
//  Copyright © 2016 Digisoft.tv. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "DiscoveryManager.h"
#import "DiscoveryManagerDelegate.h"
#import "DiscoveryProviderDelegate.h"

#import "ConnectableDevice.h"
#import "ConnectableDeviceDelegate.h"

#import "DevicePicker.h"
#import "DevicePickerDelegate.h"

#import "ServiceAsyncCommand.h"
#import "ServiceCommand.h"
#import "ServiceCommandDelegate.h"
#import "ServiceSubscription.h"

#import "CapabilityFilter.h"
#import "Launcher.h"
#import "MediaControl.h"

#import "VolumeControl.h"

#import "AppInfo.h"
#import "ImageInfo.h"
#import "MediaInfo.h"
#import "LaunchSession.h"
#import "WebAppSession.h"
#import "Feature.h"


//! Project version number for Playmigo.
FOUNDATION_EXPORT double PlaymigoVersionNumber;

//! Project version string for Playmigo.
FOUNDATION_EXPORT const unsigned char PlaymigoVersionString[];







//
//  MediaControl.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.
//  Copyright © 2016 Digisoft.tv.
//
 

#import <Foundation/Foundation.h>
#import "Capability.h"
#import "ServiceSubscription.h"
#import "Launcher.h"
#import "MediaInfo.h"
#import "MediaLaunchObject.h"
#import "Feature.h"

//Media Player
extern Feature *kMediaPlayerAny;
extern Feature *kMediaPlayerDisplayImage;
extern Feature *kMediaPlayerPlayVideo;
extern Feature *kMediaPlayerPlayAudio;
extern Feature *kMediaPlayerPlayPlaylist;
extern Feature *kMediaPlayerLoop;
extern Feature *kMediaPlayerClose;
extern Feature *kMediaPlayerMetaDataTitle;
extern Feature *kMediaPlayerMetaDataDescription;
extern Feature *kMediaPlayerMetaDataThumbnail;
extern Feature *kMediaPlayerMetaDataMimeType;
extern NSArray *kMediaPlayerCapabilities;

//Media Control
extern Feature *kMediaControlAny;
extern Feature *kMediaControlPlay;
extern Feature *kMediaControlPause;
extern Feature *kMediaControlStop;
extern Feature *kMediaControlDuration;
extern Feature *kMediaControlRewind;
extern Feature *kMediaControlFastForward;
extern Feature *kMediaControlSeek;
extern Feature *kMediaControlPlayState;
extern Feature *kMediaControlPlayStateSubscribe;
extern Feature *kMediaControlPosition;
extern Feature *kMediaControlMetadata;
extern Feature *kMediaControlMetadataSubscribe;
extern Feature *kMediaSupportApple;
extern Feature *kMediaSupportFire;
extern Feature *kMediaSupportGoogle;
extern NSArray *kMediaControlCapabilities;

typedef enum {
    MediaControlPlayStateUnknown,
    MediaControlPlayStateIdle,
    MediaControlPlayStatePlaying,
    MediaControlPlayStatePaused,
    MediaControlPlayStateBuffering,
    MediaControlPlayStateFinished
} MediaControlPlayState;

@class MediaLaunchObject;
@protocol MediaControl <NSObject>

/*!
 * Success block that is called upon any change in a media file's play state.
 *
 * @param playState Play state of the current media file
 */
typedef void (^ MediaPlayStateSuccessBlock)(MediaControlPlayState playState);

/*!
 * Success block that is called upon successfully getting the media file's current playhead position.
 *
 * @param position Current playhead position of the current media file, in seconds
 */
typedef void (^ MediaPositionSuccessBlock)(NSTimeInterval position);

/*!
 * Success block that is called upon successfully getting the media file's duration.
 *
 * @param duration Duration of the current media file, in seconds
 */
typedef void (^ MediaDurationSuccessBlock)(NSTimeInterval duration);

- (id<MediaControl>) mediaControl;
- (CapabilityPriorityLevel) mediaControlPriority;

#pragma mark Play control
- (void) playWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure;
- (void) pauseWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure;
- (void) stopWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure;

- (void) seek:(NSTimeInterval)position success:(SuccessBlock)success failure:(FailureBlock)failure;

#pragma mark Play info
- (void) getDurationWithSuccess:(MediaDurationSuccessBlock)success failure:(FailureBlock)failure;
- (void) getPositionWithSuccess:(MediaPositionSuccessBlock)success failure:(FailureBlock)failure;
- (void) getMediaInfoWithSuccess:(SuccessBlock)success failure:(FailureBlock)failure;

- (void) getPlayStateWithSuccess:(MediaPlayStateSuccessBlock)success failure:(FailureBlock)failure;
- (ServiceSubscription *)subscribePlayStateWithSuccess:(MediaPlayStateSuccessBlock)success failure:(FailureBlock)failure;

/*!
 * Success block that is called upon successfully playing/displaying a media file.
 *
 * @param launchSession LaunchSession to allow closing this media player
 * @param mediaControl MediaControl object used to control playback
 */
typedef void (^MediaPlayerDisplaySuccessBlock)(LaunchSession *launchSession, id<MediaControl> mediaControl);
typedef void (^MediaPlayerSuccessBlock)(MediaLaunchObject *mediaLaunchObject);


- (CapabilityPriorityLevel) mediaPlayerPriority;

- (void) playMediaWithMediaInfo:(MediaInfo *)mediaInfo
                     shouldLoop:(BOOL)shouldLoop
                        success:(MediaPlayerSuccessBlock)success
                        failure:(FailureBlock)failure;

- (void) playMedia:(NSURL *)mediaURL
           iconURL:(NSURL *)iconURL
             title:(NSString *)title
       description:(NSString *)description
          mimeType:(NSString *)mimeType
        shouldLoop:(BOOL)shouldLoop
           success:(MediaPlayerDisplaySuccessBlock)success
           failure:(FailureBlock)failure
__deprecated_msg("Please use playMediaWithMediaInfo:shouldLoop:success:failure: instead");

- (void) playMedia:(MediaInfo *)mediaInfo
        shouldLoop:(BOOL)shouldLoop
           success:(MediaPlayerDisplaySuccessBlock)success
           failure:(FailureBlock)failure
__deprecated_msg("Please use playMediaWithMediaInfo:shouldLoop:success:failure: instead");
@end

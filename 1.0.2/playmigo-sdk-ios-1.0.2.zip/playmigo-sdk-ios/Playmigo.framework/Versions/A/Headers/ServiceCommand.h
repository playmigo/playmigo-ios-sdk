//
//  ServiceCommand.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.
//  Copyright © 2016 Digisoft.tv.
//
 

#import <Foundation/Foundation.h>
#import "ServiceCommandDelegate.h"
#import "Capability.h"

@interface ServiceCommand : NSObject

@property (nonatomic, weak) id<ServiceCommandDelegate> delegate;
@property (nonatomic, copy) SuccessBlock callbackComplete;
@property (nonatomic, copy) FailureBlock callbackError;
@property (nonatomic, strong) NSString *HTTPMethod;
@property (nonatomic, strong) id payload;
@property (nonatomic, strong) NSURL *target;


- (instancetype) initWithDelegate:(id <ServiceCommandDelegate>)delegate target:(NSURL *)url payload:(id)payload;
+ (instancetype) commandWithDelegate:(id <ServiceCommandDelegate>)delegate target:(NSURL *)url payload:(id)payload;

-(void) send;

@end

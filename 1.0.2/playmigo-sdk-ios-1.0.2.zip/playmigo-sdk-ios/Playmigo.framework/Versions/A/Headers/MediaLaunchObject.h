//
//  MediaLaunchObject.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.
//  Copyright © 2016 Digisoft.tv. All rights reserved.
//
 

#import <Foundation/Foundation.h>
#import "MediaControl.h"
#import "LaunchSession.h"
#import "VolumeControl.h"

@protocol MediaControl;
/*! MediaLaunchObject is a container object which holds LaunchSession object,MediaControl object/or and PlayListControl object*/
@interface MediaLaunchObject : NSObject

/*! MediaControl object of Media Control*/
@property (nonatomic, strong) id<MediaControl> mediaControl;

/*! Volume Control Object of Media Control*/
@property (nonatomic, strong) id<VolumeControl> volumeControl;

/*! Launch Session object of Media Control*/
@property (nonatomic, strong) LaunchSession *session;


/*!
 * Creates an instance of MediaLaunchObject with given property values.
 *
 * @param session LaunchSession to allow closing this media Control
 * @param mediaControl MediaControl object used to control playback
 */
- (instancetype) initWithLaunchSession:(LaunchSession *)session andMediaControl:(id<MediaControl>)mediaControl;
/*!
 * Creates an instance of MediaLaunchObject with given property values.
 *
 * @param session LaunchSession to allow closing this media Control
 * @param mediaControl MediaControl object used to control playback
 * @param volumeControl VolumeControl object used to control volume
 */
- (instancetype) initWithLaunchSession:(LaunchSession *)session andMediaControl:(id<MediaControl>)mediaControl andVolumeControl:(id<VolumeControl>)volumeControl;
@end

//
//  SupportedMedia.h
//  Playmigo
//
//  Created by Mark O'Connell.
//  Copyright (c) 2016 LG Electronics. All rights reserved.
//

@interface SupportedMedia : NSObject

@property (nonatomic, retain) NSString *videoCodec;
@property (nonatomic, retain) NSString *audioCodec;
@property (nonatomic, retain) NSString *mimeType;
@property (nonatomic, retain) NSString *videoResolution;
@property (nonatomic, retain) NSString *streamingFormat;
@property (nonatomic, retain) NSString *bitRate;
@property (nonatomic, retain) NSString *frameRate;
@property (nonatomic, retain) NSString *subtitleStandards;

+ (NSMutableDictionary*)supportedMedia;

- (BOOL)equals:(NSObject *)object;

- (NSString *) getVideoCodec;
- (void) setVideoCodec: (NSString *)_videoCodec;

- (NSString *) getAudioCodec;
- (void) setAudioCodec: (NSString *)_audioCodec;

- (NSString *) getMimeType;
- (void) setMimeType: (NSString *)_mimeType;

- (NSString *) getVideoResolution;
- (void) setVideoResolution: (NSString *)_videoResolution;

- (NSString *) getStreamingFormat;
- (void) setStreamingFormat: (NSString *)_streamingFormat;

- (NSString *) getBitRate;
- (void) setBitRate: (NSString *)_bitRate;

- (NSString *) getFrameRate;
- (void) setFrameRate: (NSString *)_frameRate;

- (NSString *) getSubtitleStandards;
- (void) setSubtitleStandards: (NSString *)_subtitleStandards;

@end

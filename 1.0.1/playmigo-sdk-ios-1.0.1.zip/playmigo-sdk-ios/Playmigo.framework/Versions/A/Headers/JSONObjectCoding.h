//
//  JSONObjectCoding.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.
//  Copyright © 2016 Digisoft.tv.
//
 

#import <Foundation/Foundation.h>

@protocol JSONObjectCoding <NSObject>

- (id) initWithJSONObject:(NSDictionary*)dict;
- (NSDictionary*) toJSONObject;

@end

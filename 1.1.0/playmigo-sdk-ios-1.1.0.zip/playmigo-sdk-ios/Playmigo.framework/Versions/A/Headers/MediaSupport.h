//
//  MediaSupport.h
//  Playmigo
//
//  Created by Mark O'Connell.
//  Copyright © 2016 Digisoft.tv. All rights reserved.
//
#import "Capability.h"
#import "SupportedMedia.h"
#import "Feature.h"

extern Feature *kMediaSupportFormat;
extern NSArray *kMediaSupportCapabilities;

//Media support
extern Feature *ANY;
extern Feature *MEDIA_SUPPORT;
extern Feature *MEDIA_VIDEO; 
extern Feature *MEDIA_AUDIO; 
extern Feature *CONTAINER_MP4; 
extern Feature *CONTAINER_TS; 
extern Feature *CONTAINER_MP3; 
extern Feature *PROTOCOL_HTTP; 
extern Feature *PROTOCOL_DASH; 
extern Feature *PROTOCOL_HLS; 
extern Feature *PROTOCOL_SMOOTH_STREAMING; 
extern Feature *PROTOCOL_WIDEVINE; 
extern Feature *DRM_PLAYREADY; 
extern Feature *DRM_VCAS; 
extern Feature *DRM_WIDEVINE; 
extern Feature *DRM_FAIRPLAY; 
extern Feature *DRM_PLAIN_AES; 
extern Feature *DRM_ADOBE; 
extern Feature *VIDEO_CODEC_AVC; 
extern Feature *VIDEO_CODEC_HEVC; 
extern Feature *VIDEO_CODEC_WEBM; 
extern Feature *AUDIO_CODEC_AAC; 
extern Feature *AUDIO_CODEC_AC3; 
extern Feature *AUDIO_CODEC_MP3; 
extern Feature *VIDEO_RESOLUTION_UHD; 
extern Feature *VIDEO_RESOLUTION_HD; 
extern Feature *VIDEO_RESOLUTION_SD; 
extern Feature *SUBTITLE_WEBVTT; 
extern Feature *SUBTITLE_TTML; 
extern Feature *SUBTITLE_CEA608; 

//Default media supports
extern NSArray *DefaultMediaSupport;
extern NSArray *DefaultAudioOnlyMediaSupport;

extern NSMutableArray *JSONCapabilities;

@protocol MediaSupport <NSObject>

- (instancetype)mediaSupport;
- (CapabilityPriorityLevel *)mediaSupportPriority;
- (NSMutableArray *)supportedMedia;
- (void)setSupportedMedia: (SupportedMedia *)supportedMedia;

@end

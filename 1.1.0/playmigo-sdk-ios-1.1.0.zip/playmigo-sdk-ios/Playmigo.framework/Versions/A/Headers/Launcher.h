//
//  Launcher.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.
//  Copyright © 2016 Digisoft.tv.
//


#import <Foundation/Foundation.h>
#import "Capability.h"
#import "AppInfo.h"
#import "ServiceSubscription.h"
#import "LaunchSession.h"
#import "MediaLaunchObject.h"
#import "WebAppSession.h"
#import "MediaControl.h"
#import "MediaSupport.h"
#import "Feature.h"


extern Feature *kWebAppLauncherAny;
extern Feature *kWebAppLauncherLaunch;
extern Feature *kWebAppLauncherLaunchParams;
extern Feature *kWebAppLauncherMessageSend;
extern Feature *kWebAppLauncherMessageReceive;
extern Feature *kWebAppLauncherMessageSendJSON;
extern Feature *kWebAppLauncherMessageReceiveJSON;
extern Feature *kWebAppLauncherConnect;
extern Feature *kWebAppLauncherDisconnect;
extern Feature *kWebAppLauncherJoin;
extern Feature *kWebAppLauncherClose;
extern Feature *kWebAppLauncherPin;
extern NSArray *kWebAppLauncherCapabilities;

extern Feature *kLauncherAny;
extern Feature *kLauncherApp;
extern Feature *kLauncherAppParams;
extern Feature *kLauncherAppClose;
extern Feature *kLauncherAppList;
extern Feature *kLauncherAppState;
extern Feature *kLauncherAppStateSubscribe;
extern Feature *kLauncherRunningApp;
extern Feature *kLauncherRunningAppSubscribe;
extern NSArray *kLauncherCapabilities;

@class MediaLaunchObject;
@class WebAppSession;
@protocol WebAppPinStatusBlock;

@protocol MediaControl;

@protocol Launcher <NSObject>

/*!
 * Success block that is called upon requesting info about the current running app.
 *
 * @param appInfo Object containing info about the running app
 */
typedef void (^ AppInfoSuccessBlock)(AppInfo *appInfo);

/*!
 * Success block that is called upon successfully launching an app.
 *
 * @param launchSession LaunchSession Object containing important information about the app's launch session
 */
typedef void (^ AppLaunchSuccessBlock)(LaunchSession *launchSession);

/*!
 * Success block that is called upon successfully getting the app list.
 *
 * @param appList Array containing an AppInfo object for each available app on the device
 */
typedef void (^ AppListSuccessBlock)(NSArray *appList);

/*!
 * Success block that is called upon successfully getting an app's state.
 *
 * @param running Whether the app is currently running
 * @param visible Whether the app is currently visible on the screen
 */
typedef void (^ AppStateSuccessBlock)(BOOL running, BOOL visible);

- (id<Launcher>) launcher;
- (CapabilityPriorityLevel) launcherPriority;

#pragma mark Launch & close
- (void)launchApp:(NSString *)appId success:(AppLaunchSuccessBlock)success failure:(FailureBlock)failure;
- (void)launchAppWithInfo:(AppInfo *)appInfo success:(AppLaunchSuccessBlock)success failure:(FailureBlock)failure;
- (void)launchAppWithInfo:(AppInfo *)appInfo params:(NSDictionary *)params success:(AppLaunchSuccessBlock)success failure:(FailureBlock)failure;

- (void)closeApp:(LaunchSession *)launchSession success:(SuccessBlock)success failure:(FailureBlock)failure;

#pragma mark App Info
- (void) getAppListWithSuccess:(AppListSuccessBlock)success failure:(FailureBlock)failure;

- (void) getRunningAppWithSuccess:(AppInfoSuccessBlock)success failure:(FailureBlock)failure;
- (ServiceSubscription *)subscribeRunningAppWithSuccess:(AppInfoSuccessBlock)success failure:(FailureBlock)failure;

- (void)getAppState:(LaunchSession *)launchSession success:(AppStateSuccessBlock)success failure:(FailureBlock)failure;
- (ServiceSubscription *)subscribeAppState:(LaunchSession *)launchSession success:(AppStateSuccessBlock)success failure:(FailureBlock)failure;

/*!
 * Success block that is called upon successfully launch of a web app.
 *
 * @param webAppSession Object containing important information about the web app's session. This object is required to perform many functions with the web app, including app-to-app communication, media playback, closing, etc.
 */
typedef void (^ WebAppLaunchSuccessBlock)(WebAppSession *webAppSession);

- (CapabilityPriorityLevel) webAppLauncherPriority;

- (void) launchWebApp:(NSString *)webAppId success:(WebAppLaunchSuccessBlock)success failure:(FailureBlock)failure;
- (void) launchWebApp:(NSString *)webAppId params:(NSDictionary *)params success:(WebAppLaunchSuccessBlock)success failure:(FailureBlock)failure;

/*!
 * This method requires pairing on webOS
 */
- (void) launchWebApp:(NSString *)webAppId relaunchIfRunning:(BOOL)relaunchIfRunning success:(WebAppLaunchSuccessBlock)success failure:(FailureBlock)failure;

/*!
 * This method requires pairing on webOS
 */
- (void) launchWebApp:(NSString *)webAppId params:(NSDictionary *)params relaunchIfRunning:(BOOL)relaunchIfRunning success:(WebAppLaunchSuccessBlock)success failure:(FailureBlock)failure;

- (void) joinWebApp:(LaunchSession *)webAppLaunchSession success:(WebAppLaunchSuccessBlock)success failure:(FailureBlock)failure;
- (void) joinWebAppWithId:(NSString *)webAppId success:(WebAppLaunchSuccessBlock)success failure:(FailureBlock)failure;

- (void) closeWebApp:(LaunchSession *)launchSession success:(SuccessBlock)success failure:(FailureBlock)failure;

- (void) pinWebApp:(NSString *)webAppId success:(SuccessBlock)success failure:(FailureBlock)failure;

- (void) unPinWebApp:(NSString *)webAppId success:(SuccessBlock)success failure:(FailureBlock)failure;

//- (void) isWebAppPinned:(NSString *)webAppId success:(WebAppPinStatusBlock)success failure:(FailureBlock)failure;
//
//- (ServiceSubscription *)subscribeIsWebAppPinned:(NSString*)webAppId success:(WebAppPinStatusBlock)success failure:(FailureBlock)failure;

@end

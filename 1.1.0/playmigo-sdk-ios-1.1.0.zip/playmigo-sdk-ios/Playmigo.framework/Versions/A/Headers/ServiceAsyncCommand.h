//
//  ServiceAsyncCommand.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.
//  Copyright © 2016 Digisoft.tv.
//
 

#import "ServiceCommand.h"

@interface ServiceAsyncCommand : ServiceCommand

+ (instancetype) asyncWithDelegate:(id <ServiceCommandDelegate>)delegate target:(NSURL *)URL payload:(id)payload;

@end

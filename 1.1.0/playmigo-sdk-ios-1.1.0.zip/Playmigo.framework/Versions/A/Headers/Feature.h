//
//  Feature.h
//  Playmigo
//
//  Created by Mark Horgan on 16/12/2016.
//  Copyright © 2016 Digisoft.tv. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Feature : NSObject

/*! Name of the feature being used*/
@property (strong, nonatomic) NSString *mName;
/*! Array containing the list of features that are aggregated*/
@property (strong, nonatomic) NSMutableArray <Feature *> *mOrList;
/*! Array containing the list of features that are dependencies*/
@property (strong, nonatomic) NSMutableArray <Feature *> *mDepList;

/*!
 * Compares two features and aggregates them
 * @param ft Feature object to be compared
 * @return Feature return the aggregated feature object
 */
-(Feature *) or:(Feature *) ft;

/*!
 * Creates a dependency between two features.
 *
 * Example: 
 * f = [x dependsOn:[d1 dependsOn:d2]];
 * f will contain feature x
 * x will contain feature d1
 * d1 will contain feature d2
 * There will be only ever one object in the feature array, and this object can contain another feature object and so on.
 *
 * @param ft Feature object to be compared
 * @return Feature return the dependency as a feature object
 */
-(Feature *) dependsOn:(Feature *) ft;

/*! Test to see if a feature is aggregated */
-(BOOL) isAggregate;

/*! Test to see if a feature has a dependency */
-(BOOL) hasDeps;

/*! Create a singleton instance of the Feature Class*/
+ (Feature *) _sharedManager;
+ (Feature *) sharedManager;

/*! Initialise a Feature with a name
 * @param name The name of the feature that is to be created
 */
- (instancetype)initWithNSString:(NSString *)name;
@end

//
//  ServiceConfigDelegate.h
//  Playmigo
//
//  Created by Mark Horgan 12/12/16.
//  Copyright © 2016 Digisoft.tv.
//
 

#import <Foundation/Foundation.h>

@class ServiceConfig;

@protocol ServiceConfigDelegate <NSObject>

- (void) serviceConfigUpdate:(ServiceConfig*)serviceConfig;

@end
